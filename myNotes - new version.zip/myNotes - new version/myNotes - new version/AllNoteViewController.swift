//
//  ViewController.swift
//  myNotes - new version
//
//  Created by Joana Valadao on 09/04/17.
//  Copyright © 2017 Joana Bittencourt. All rights reserved.
//

import UIKit
import MobileCoreServices
import Photos
import MapKit
import CoreLocation

class AllNoteViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate,
UINavigationControllerDelegate, CLLocationManagerDelegate, MKMapViewDelegate{

    // MARK: Properties
    @IBOutlet weak var noteTitle: UITextField!
    @IBOutlet weak var noteType: UISegmentedControl!
    
    @IBOutlet weak var noteView: UIView!
    @IBOutlet weak var photoView: UIView!
    
    @IBOutlet weak var doneButton: UIButton!
    
    private var noteViewController : TextViewController!
    private var photoViewController : PhotoTableViewController!
    private var actualLatitude : Double!
    private var actualLongitude : Double!
    // manages the map
    let manager = CLLocationManager()
    
    
    var note : Note!
    var isLeaving = true
    var newNote : Bool!
    var selectedRow : Int!
    var masterView : NotesTableViewController!
    var databasePath : String!
    
    /*****************************************************************************/
    // MARK: ViewController methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //setting up the values
        noteTitle.text = note.title
        noteViewController.textNote.text = note.text
        
        //starts with the noteView
        noteView.isHidden = false
        photoView.isHidden = true
        
        //delegates
        noteTitle.delegate = self
        
        //setups
        doneButton.isHidden = true
        
        // Setup manager
        manager.delegate = self
        manager.distanceFilter = kCLLocationAccuracyNearestTenMeters;
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        isLeaving = true
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        if isLeaving {
            if newNote {
                if !((noteTitle.text == "Title" || (noteTitle.text?.isEmpty)!) && note.text.isEmpty && note.images.count == 0) {
                    note.setTitle(title: noteTitle.text ?? " ")
                    masterView.updateNote(id: note.id, index: selectedRow)
                    masterView.tableView.reloadData()
                } else {
                    masterView.deleteNote(id: note.id, index: selectedRow)
                }
            } else if !newNote {
                note.setTitle(title: noteTitle.text ?? " ")
                masterView.updateNote(id: note.id, index: selectedRow)
                masterView.tableView.reloadData()
            }
        }
    }

    
    /*****************************************************************************/
    // MARK : Actions
    @IBAction func changeNoteType(_ sender: UISegmentedControl) {
        
        switch noteType.selectedSegmentIndex {
        case 0:
            noteView.isHidden = false
            photoView.isHidden = true
            if let tv = photoViewController.activeTextView {
                tv.resignFirstResponder()
            }
        case 1:
            noteView.isHidden = true
            photoView.isHidden = false
            noteViewController.textNote.resignFirstResponder()
        default:
            break; 
        }
        doneButton.isHidden = true
    }
    
    @IBAction func resignKeyboard(_ sender: UIButton) {
        if noteType.selectedSegmentIndex == 0 {
            noteViewController.textNote.resignFirstResponder()
        } else {
            photoViewController.activeTextView.resignFirstResponder()
        }
        doneButton.isHidden = true
    }
    

    @IBAction func takePhoto(_ sender: UIButton){
        isLeaving = false
        // configuring the UI
        if noteType.selectedSegmentIndex == 0 {
            noteType.selectedSegmentIndex = 1
            noteView.isHidden = true
            photoView.isHidden = false
        }
        
        // Test if the camera is available
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
            
            let imagePicker = UIImagePickerController()
            
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera
            imagePicker.mediaTypes = [kUTTypeImage as String]
            imagePicker.allowsEditing = false
            
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    @IBAction func printNote(_ sender: UIButton) {
        print(note.description)
    }
    
    
    /*****************************************************************************/
    // MARK: TextField delegates
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField, reason: UITextFieldDidEndEditingReason) {
        textField.resignFirstResponder()
    }
    
    
    /*****************************************************************************/
    // MARK: Segues
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let viewController = segue.destination as? TextViewController {
            self.noteViewController = viewController
            self.noteViewController.mainViewController = self
        } else if let viewController = segue.destination as? PhotoTableViewController {
            self.photoViewController = viewController
            self.photoViewController.mainViewController = self
        }
    }
    
    /*****************************************************************************/
    // MARK: Photo Controller
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        let mediaType = info[UIImagePickerControllerMediaType] as! NSString
        self.dismiss(animated: true, completion: nil)
        
        if mediaType.isEqual(to: kUTTypeImage as String) {
            let image = info[UIImagePickerControllerOriginalImage] as! UIImage
            
            // coordinates
            let photoLatitude = actualLatitude!
            let photoLongitude = actualLongitude!
            
            // saving the image
            let noteImage = NoteImage(image: image, latitude: photoLatitude, longitude: photoLongitude, comment: "")
            let id = saveNoteImageBD(noteImage: noteImage)
            if id == -1 {
                showAlert(title: "Database error", message: "Error saving image on database")
            } else {
                noteImage.setID(id: id)
                let statusSave = saveImageDirectory(image: image, name: noteImage.photoName)
                if statusSave {
                    note.addImage(image: noteImage)
                    photoViewController.photoTableView.reloadData()
                } else {
                    showAlert(title: "Failed saving photo", message: "Failed to save the image into directory")
                }
            }
        }
    }
    
    
    /*****************************************************************************/
    // MARK: Map control
    
    //Getting the position and setting the map
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        // the array locations stores all the user's positions, and the position 0 is the most recent one
        let location = locations[0]
        
        self.actualLatitude = location.coordinate.latitude
        self.actualLongitude = location.coordinate.longitude
    }

    
    /*****************************************************************************/
    // MARK: Database
    func saveNoteImageBD(noteImage : NoteImage) -> Int32{
        var id : Int32 = -1
        
        let myNotesDB = FMDatabase(path: databasePath as String)
        if (myNotesDB?.open())! {
            let idNote = note.id
            let latitude = noteImage.latitude
            let longitude = noteImage.longitude
            let comment = noteImage.comment
            
            let sql = "INSERT INTO images (id_note, latitude, longitude, comment) VALUES (\(idNote!), \(latitude), \(longitude), '\(comment)')"
            
            let result = myNotesDB?.executeUpdate(sql, withArgumentsIn: nil)
            
            if !result! {
                print("addImage - Error 1: \(String(describing: myNotesDB?.lastErrorMessage()))")
            } else {
                let sqlRowID = "SELECT last_insert_rowid() as id"
                let seqID : FMResultSet? = myNotesDB?.executeQuery(sqlRowID, withArgumentsIn: nil)
                if (seqID?.next())! {
                    id = (seqID?.int(forColumn: "id"))!
                } else {
                    id = -1
                }
            }
            myNotesDB?.close()
        } else {
            print("newNote - Error 2: \(String(describing: myNotesDB?.lastErrorMessage()))")
        }
        return id
    }
    
    /*****************************************************************************/
    // MARK : Private methods
    private func saveImageDirectory (image: UIImage, name: String) -> Bool {
        
        let imageData = UIImageJPEGRepresentation(image, 1.0)
        let docDir = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let imageURL = docDir.appendingPathComponent(name)
        
        do {
            try imageData?.write(to: imageURL)
            return true
        } catch {
            return false
        }
    }
    
    private func showAlert(title: String, message: String){
        // Create a Modal to receive data form user
        let alert = UIAlertController(title: title,
                                      message: message,
                                      preferredStyle: .alert)
        
        // Create a button cancel and release the modal
        let okButton = UIAlertAction(title: "Ok", style: .default)
        
        // Adding ... propreties in Modal
        alert.addAction(okButton)
        
        // Show the Modal to the user
        present(alert, animated: true)
    }

}

