//
//  NotesTableViewController.swift
//  myNotes - new version
//
//  Created by Joana Valadao on 13/04/17.
//  Copyright © 2017 Joana Bittencourt. All rights reserved.
//

import UIKit

class NotesTableViewController: UITableViewController {

    var data : [Note] = []
    var noteViewController : AllNoteViewController!
    var databasePath : String = ""
    
    /*****************************************************************************/
    // MARK: ViewController methods
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.delegate = self
        tableView.dataSource = self
        
        //DATABASE
        initializeDB()
        loadData()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*****************************************************************************/
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return data.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        cell.textLabel?.text = data[indexPath.row].title

        return cell
    }

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            let index = indexPath.row
            deleteNote(id: data[index].id, index: index)
//            data.remove(at: index)
//            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    
    /*****************************************************************************/
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let viewController = segue.destination as? AllNoteViewController{
            noteViewController = viewController
            noteViewController.masterView = self
            noteViewController.databasePath = self.databasePath
            if sender is UIBarButtonItem {
                noteViewController.selectedRow = newNote()
                noteViewController.newNote = true
                noteViewController.note = data[noteViewController.selectedRow]
            }
            else {
                let index = (tableView.indexPathForSelectedRow?.row)!
                noteViewController.selectedRow = index
                noteViewController.note = data[index]
                noteViewController.newNote = false
            }
        }
    }
    
    /*****************************************************************************/
    // MARK: Database
    func initializeDB(){
        let fileManager = FileManager.default
        let dirPaths = fileManager.urls(for: .documentDirectory, in: .userDomainMask)
        
        databasePath = dirPaths[0].appendingPathComponent("myNotes.db").path
        
        if !fileManager.fileExists(atPath: databasePath as String){
            let myNotesDB = FMDatabase(path: databasePath as String)
            
            if myNotesDB == nil {
                print("initializeDB - Error 1: \(String(describing: myNotesDB?.lastErrorMessage()))")
            }
            
            if (myNotesDB?.open())! {
                var sql_stmt = "CREATE TABLE IF NOT EXISTS notes (ID INTEGER PRIMARY KEY AUTOINCREMENT, TITLE TEXT, NOTE TEXT)"
                
                // checking if the table was created
                if !(myNotesDB?.executeStatements(sql_stmt))! {
                    print("initializeDB - Error 2: \(String(describing: myNotesDB?.lastErrorMessage()))")
                }
                
                sql_stmt = "CREATE TABLE IF NOT EXISTS images (ID INTEGER PRIMARY KEY AUTOINCREMENT, ID_NOTE INTEGER, LATITUDE REAL, LONGITUDE REAL, COMMENT TEXT)"
                
                // checking if the table was created
                if !(myNotesDB?.executeStatements(sql_stmt))! {
                    print("initializeDB - Error 3: \(String(describing: myNotesDB?.lastErrorMessage()))")
                }
                
                myNotesDB?.close()
            } else {
                print("initializeDB - Error 4: \(String(describing: myNotesDB?.lastErrorMessage()))")
            }
        }
        print(databasePath as String)
    }
    
    func loadData(){
        let myNotesDB = FMDatabase(path: databasePath as String)
        if (myNotesDB?.open())! {
            
//            let _ = myNotesDB?.executeUpdate("DELETE FROM images", withArgumentsIn: nil)

            let querySQL = "SELECT ID, TITLE, NOTE FROM notes"
            
            let results: FMResultSet? = myNotesDB?.executeQuery(querySQL, withArgumentsIn: nil)
            
            // taking a look if the first row exists
            while (results?.next())! {
                let idNote = results?.int(forColumn: "id")
                let note = Note(id: idNote!, title: (results?.string(forColumn: "title"))!, text: (results?.string(forColumn: "note"))!)
                
                //retrieving the images
                let queryImage = "SELECT ID, LATITUDE, LONGITUDE, COMMENT FROM images WHERE ID_NOTE = \(idNote ?? 0)"
                let imageResult : FMResultSet? = myNotesDB?.executeQuery(queryImage, withArgumentsIn: nil)
                
                while (imageResult?.next())! {
                    let imageID = imageResult?.int(forColumn: "id")
                    let latitude = imageResult?.double(forColumn: "latitude")
                    let longitude = imageResult?.double(forColumn: "longitude")
                    let comment = imageResult?.string(forColumn: "comment")
                    
                    let newImage = NoteImage(id: imageID!, latitude: latitude!, longitude: longitude!, comment: comment!)
                    newImage.getImage()
                    
                    note.addImage(image: newImage)
                }
                data.append(note)
            }
            myNotesDB?.close()
        } else {
            print("loadData - Error 1: \(String(describing: myNotesDB?.lastErrorMessage()))")
        }
        
    }
    
    func newNote() -> Int {
        var index = -1
        let myNotesDB = FMDatabase(path: databasePath as String)
        if (myNotesDB?.open())! {
            let newNote = Note()
            let sql_stmt = "INSERT INTO notes (title, note) VALUES ('\(newNote.title)', '\(newNote.text)')"
            let result = myNotesDB?.executeUpdate(sql_stmt, withArgumentsIn: nil)
            
            if !result! {
                print("newNote - Error 1: \(String(describing: myNotesDB?.lastErrorMessage()))")
            } else {
                let sqlRowID = "SELECT last_insert_rowid() as id"
                let seqID : FMResultSet? = myNotesDB?.executeQuery(sqlRowID, withArgumentsIn: nil)
                if (seqID?.next())! {
                    let id = (seqID?.int(forColumn: "id"))!
                    newNote.setID(id: id)
                    data.append(newNote)
                    index = data.count - 1
                }
            }
            myNotesDB?.close()
        } else {
            print("newNote - Error 2: \(String(describing: myNotesDB?.lastErrorMessage()))")
        }
        return index
    }
    
    
    func deleteNote(id: Int32, index: Int){
        let myNotesDB = FMDatabase(path: databasePath as String)
        if (myNotesDB?.open())! {
            
            let note = data[index]
            for image in note.images {
                let result = image.deleteImageFromDirectory()
                if result {
//                    showAlert(title: "Image deleted", message: "")
                } else {
                    showAlert(title: "Error deleting image", message: "")
                }
            }
            
            let deleteImages = "DELETE FROM images WHERE id_note = \(id)"
            _ = myNotesDB?.executeUpdate(deleteImages, withArgumentsIn: nil)
            let deleteSQL = "DELETE FROM notes WHERE id = \(id)"
            let result = myNotesDB?.executeUpdate(deleteSQL, withArgumentsIn: nil)
            
            if !result! {
                print("deleteNote - Error 1: \(String(describing: myNotesDB?.lastErrorMessage()))")
            }
            myNotesDB?.close()
            data.remove(at: index)
            tableView.reloadData()
        }
    }
    
    func updateNote(id: Int32, index: Int){
        let myNotesDB = FMDatabase(path: databasePath as String)
        if (myNotesDB?.open())! {
            var updateSQL  = "UPDATE notes\n"
                updateSQL += "SET title = '\(data[index].title)',\n"
                updateSQL += "    note  = '\(data[index].text)'\n"
                updateSQL += "WHERE id = \(id)"
            let result = myNotesDB?.executeUpdate(updateSQL, withArgumentsIn: nil)
            
            if !result! {
                print("updateNote - Error 1: \(String(describing: myNotesDB?.lastErrorMessage()))")
            }
            myNotesDB?.close()
        }
    }
    
    
    /*****************************************************************************/
    // MARK: Private methods

    
    private func showAlert(title: String, message: String){
        // Create a Modal to receive data form user
        let alert = UIAlertController(title: title,
                                      message: message,
                                      preferredStyle: .alert)
        
        // Create a button cancel and release the modal
        let okButton = UIAlertAction(title: "Ok", style: .default)
        
        // Adding ... propreties in Modal
        alert.addAction(okButton)
        
        // Show the Modal to the user
        present(alert, animated: true)
    }
}


