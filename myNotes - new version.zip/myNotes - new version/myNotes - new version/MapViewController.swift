//
//  MapViewController.swift
//  myNotes - new version
//
//  Created by Joana Valadao on 12/04/17.
//  Copyright © 2017 Joana Bittencourt. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate{

    //MARK: Properties
    var latitude : Double!
    var longitude : Double!
    
    @IBOutlet weak var map: MKMapView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        map.delegate = self
        map.showsUserLocation = true
        map.userTrackingMode = .follow

        // here we define the map's zoom. The value 0.01 is a pattern
        let span:MKCoordinateSpan = MKCoordinateSpanMake(0.01, 0.01)
        
        let myLocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitude, longitude)
        
        let region:MKCoordinateRegion = MKCoordinateRegionMake(myLocation, span)
        
        //setting the map
        map.setRegion(region, animated: true)
        
        
        // Region data
        let title = "Photo Region"
        let coordinate = CLLocationCoordinate2DMake(latitude, longitude)
        
        // Setup annotation
        let userAnnotation = MKPointAnnotation()
        userAnnotation.coordinate = coordinate;
        userAnnotation.title = "\(title)";
        map.addAnnotation(userAnnotation)
    
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
