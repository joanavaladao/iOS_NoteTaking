//
//  PhotoTableViewController.swift
//  myNotes - new version
//
//  Created by Joana Valadao on 09/04/17.
//  Copyright © 2017 Joana Bittencourt. All rights reserved.
//

import UIKit


class PhotoTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextViewDelegate {

    /*****************************************************************************/
    // MARK: Properties
    @IBOutlet weak var photoTableView: UITableView!
    
    var mainViewController : AllNoteViewController!
    var activeTextView : UITextView!

    /*****************************************************************************/
    // MARK: ViewController methods
    override func viewDidLoad() {
        super.viewDidLoad()

        photoTableView.delegate = self
        photoTableView.dataSource = self

    }

    /*****************************************************************************/
    // MARK: - Table view delegate and data source

    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        let numberOfRows = mainViewController.note == nil ? 0 : mainViewController.note.images.count
        return numberOfRows
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "photoCell", for: indexPath) as? PhotoTableViewCell {
            
            let line = mainViewController.note.images[indexPath.row]
            cell.imageNote.image = line.photo
            
            cell.comment.delegate = self
            cell.comment.text = line.comment
            cell.comment.tag = indexPath.row
            cell.buttonShowMap.tag = indexPath.row
            cell.buttonShowImage.tag = indexPath.row
            cell.latitude = line.latitude
            cell.longitude = line.longitude
            
            return cell
        } else {
            fatalError("The dequeued cell is not an instance of PhotoTableViewCell.")
        }
    }
    
    // Override to support editing the table view.
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        let noteImage = mainViewController.note.images[indexPath.row]
        
        if editingStyle == .delete {
            // Delete from the directory
            let deleteFromDirectory = deleteImageFromDirectory(name: noteImage.photoName)
            if deleteFromDirectory {
                let deleteFromDB = deleteImageFromDB(noteImage: noteImage)
                if deleteFromDB{
                    // Delete the row from the data source
                    mainViewController.note.removeImage(index: indexPath.row)
                    photoTableView.deleteRows(at: [indexPath], with: .fade)
//                    showAlert(title: "Success", message: "Photo deleted")
                } else {
                    showAlert(title: "Error deleting Database", message: "Error deleting data from database")
                }
            } else {
                showAlert(title: "Error deleting from directory", message: "Error deleting image from directory")
            }
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    
    /*****************************************************************************/
    // MARK : TextView delegates
    func textViewDidBeginEditing(_ textView: UITextView) {
        mainViewController.doneButton.isHidden = false
    }

    func textViewDidChange(_ textView: UITextView) {
        let id = mainViewController.note.images[textView.tag].imageID
        mainViewController.note.images[textView.tag].comment = textView.text
        
        let updateSucceeded = updateImageCommentBD(id: id!, comment: textView.text!)
        if !updateSucceeded {
            showAlert(title: "Error updating image comment", message: "Error updating image comment in database")
        }
        activeTextView = textView
    }
    
    /*****************************************************************************/
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let viewController = segue.destination as? MapViewController {
            if let btn = sender as? UIButton {
                mainViewController.isLeaving = false
                let index = btn.tag
                viewController.latitude = mainViewController.note.images[index].latitude
                viewController.longitude = mainViewController.note.images[index].longitude
            }
        } else if let viewController = segue.destination as? ImageViewController {
            if let btn = sender as? UIButton {
                mainViewController.isLeaving = false
                let index = btn.tag
                viewController.photoImage = mainViewController.note.images[index].photo
            }
        }
    }
    

    
    /*****************************************************************************/
    // MARK: Database
    func deleteImageFromDB(noteImage : NoteImage) -> Bool{
        var deleteSucceded = false
        
        let myNotesDB = FMDatabase(path: mainViewController.databasePath as String)
        if (myNotesDB?.open())! {

            
            let sql = "DELETE FROM images WHERE id = \(noteImage.imageID!)"
            
            let result = myNotesDB?.executeUpdate(sql, withArgumentsIn: nil)
            
            if !result! {
                print("deleteNoteImageBD - Error 1: \(String(describing: myNotesDB?.lastErrorMessage()))")
            } else {
                deleteSucceded = true
            }
            myNotesDB?.close()
        } else {
            print("newNote - Error 2: \(String(describing: myNotesDB?.lastErrorMessage()))")
        }
        return deleteSucceded
    }
    
    func updateImageCommentBD(id : Int32, comment : String) -> Bool {
        var updateSucceded = false
        
        let myNotesDB = FMDatabase(path: mainViewController.databasePath as String)
        if (myNotesDB?.open())! {
            
            
            let sql = "UPDATE images SET comment = '\(comment)' WHERE id = \(id)"
            
            let result = myNotesDB?.executeUpdate(sql, withArgumentsIn: nil)
            
            if !result! {
                print("updateImageCommentBD - Error 1: \(String(describing: myNotesDB?.lastErrorMessage()))")
            } else {
                updateSucceded = true
            }
            myNotesDB?.close()
        } else {
            print("newNote - Error 2: \(String(describing: myNotesDB?.lastErrorMessage()))")
        }
        return updateSucceded
    }
    
    
    /*****************************************************************************/
    // MARK: Private methods
    func deleteImageFromDirectory(name: String) -> Bool {
        let docDir = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let imageURL = docDir.appendingPathComponent(name)
        
        do {
            try FileManager.default.removeItem(at: imageURL)
            return true
        } catch {
            return false
        }
    }
    
    private func showAlert(title: String, message: String){
        // Create a Modal to receive data form user
        let alert = UIAlertController(title: title,
                                      message: message,
                                      preferredStyle: .alert)
        
        // Create a button cancel and release the modal
        let okButton = UIAlertAction(title: "Ok", style: .default)
        
        // Adding ... propreties in Modal
        alert.addAction(okButton)
        
        // Show the Modal to the user
        present(alert, animated: true)
    }
}
