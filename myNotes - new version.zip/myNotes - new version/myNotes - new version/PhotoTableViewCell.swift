//
//  PhotoTableViewCell.swift
//  myNotes - new version
//
//  Created by Joana Valadao on 10/04/17.
//  Copyright © 2017 Joana Bittencourt. All rights reserved.
//

import UIKit

class PhotoTableViewCell: UITableViewCell/*, UITextViewDelegate */{
    
    
    // MARK: Properties
    @IBOutlet weak var imageNote: UIImageView!
    @IBOutlet weak var comment: UITextView!
    @IBOutlet weak var buttonShowMap: UIButton!
    @IBOutlet weak var buttonShowImage: UIButton!
  
    var latitude : Double = 0.0
    var longitude : Double = 0.0

    // MARK: Cell methods
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
