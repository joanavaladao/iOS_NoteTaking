//
//  Note.swift
//  myNotes - new version
//
//  Created by Joana Valadao on 09/04/17.
//  Copyright © 2017 Joana Bittencourt. All rights reserved.
//

import UIKit

class Note {
    
    // MARK: Properties
    var id : Int32!
    public private(set) var title : String
    public private(set) var text : String
    public private(set) var images : [NoteImage]
    
    
    // MARK: Constructors
    init() {
        self.title = "Title"
        self.text = ""
        images = []
    }
    
    init (title : String, text : String){
        self.title = title
        self.text = text
        self.images = []
    }
    
    init (id: Int32, title : String, text : String){
        self.id = id
        self.title = title
        self.text = text
        self.images = []
    }
    
    init (title : String, text : String, images : [NoteImage]){
        self.title = title
        self.text = text
        self.images = images
    }
    
    
    // MARK: Settlers
    func setTitle(title: String){
        self.title = title
    }
    
    func setText(text: String){
        self.text = text
    }
    
    func setID(id: Int32){
        self.id = id
    }
    
    func addImage(image : NoteImage){
        self.images.append(NoteImage(image: image))
    }
    
    func addImage(image: UIImage, latitude : Double, longitude : Double, comment : String){
        let newImage = NoteImage(image: image, latitude: latitude, longitude: longitude, comment: comment)
        self.images.append(newImage)
    }
    
    public func removeImage(index : Int) -> Bool{
        if index < images.count {
            images.remove(at: index)
            return true
        }
        return false
    }
    
    
    public var description : String{
        var result = "*********************\n"
        result += "ID: \(self.id!)\n"
        result += "Title: \(self.title)\n"
        result += "Text: \(self.text)\n"
        for i in self.images {
            result += "-------------------\n"
            result += "ID: \(i.imageID)\n"
            result += "Image: \(i.photo)\n"
            result += "Comment: \(i.comment)\n"
            result += "Latitude: \(i.latitude)\n"
            result += "Longitude: \(i.longitude)\n"
        }
        result += "*********************\n"
        return result
    }
}


class NoteImage {
    
    var imageID : Int32!
    var photo : UIImage
    var photoName: String {
        get {
            if let id = imageID {
                return "myNotesIMG_\(id)"
            } else {
                return "myNotesIMG"
            }
        }
    }
    var latitude : Double
    var longitude : Double
    var comment : String
    
    var description : String {
        get {
            return "ID: \(imageID)\nName: \(photoName)\nLatitude: \(latitude)\nLongitude: \(longitude)\nComment: \(comment)"
        }
    }
    
    init () {
        self.photo = UIImage(named: "defaultPhoto")!
        self.latitude = 0.0
        self.longitude = 0.0
        self.comment = ""
    }
    
    init (image: UIImage, latitude : Double, longitude : Double, comment : String) {
        self.photo = image
        self.latitude = latitude
        self.longitude = longitude
        self.comment = comment
    }
    
    init (id: Int32, image: UIImage, latitude : Double, longitude : Double, comment : String) {
        self.imageID = id
        self.photo = image
        self.latitude = latitude
        self.longitude = longitude
        self.comment = comment
    }
    
    init (id: Int32, latitude : Double, longitude : Double, comment : String) {
        self.imageID = id
        self.photo = UIImage(named: "defaultPhoto")!
        self.latitude = latitude
        self.longitude = longitude
        self.comment = comment
    }
    
    init(image : NoteImage){
        self.imageID = image.imageID
        self.photo = image.photo
        self.latitude = image.latitude
        self.longitude = image.longitude
        self.comment = image.comment
    }
    
    func setID(id: Int32){
        if (imageID == nil) {
            self.imageID = id
        }
    }
    
    func setPhoto(image: UIImage){
        self.photo = image
    }
    
    
    func getImage(){
        let docDir = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let imageURL = docDir.appendingPathComponent(photoName)
        
        if let result =  UIImage(contentsOfFile: imageURL.path) {
            photo = result
        } else {
            photo = UIImage(named: "defaultPhoto")!
        }
    }
    
    func deleteImageFromDirectory() -> Bool {
        let docDir = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let imageURL = docDir.appendingPathComponent(photoName)
        
        do {
            try FileManager.default.removeItem(at: imageURL)
            return true
        } catch {
            return false
        }
    }
}
